/* =========================================================================
   VN System — vn-charts.js · v1
   Gráficos em canvas: <canvas data-chart="donut|bars" data-labels='[..]' data-values='[..]'>
   Cores seguem o tema (html[data-theme]) e redesenham quando o tema muda.
   ========================================================================= */
(function () {
  'use strict';

  /* ---------- Cores ---------- */
  function colorFor(label, i) {
    var l = String(label || '').toLowerCase();
    if (/feit|conclu|aprov/.test(l)) return '#22c55e';
    if (/pend|abert/.test(l)) return '#f59e0b';
    if (/andam|rota|execu/.test(l)) return '#3b82f6';
    if (/cancel|recus/.test(l)) return '#ef4444';
    var pal = ['#60a5fa', '#22c55e', '#f59e0b', '#ef4444', '#a78bfa', '#f472b6', '#2dd4bf', '#fb923c'];
    return pal[i % pal.length];
  }
  function themeColors() {
    var light = document.documentElement.getAttribute('data-theme') !== 'dark';
    return {
      text: light ? '#0f172a' : '#eaf1ff',
      muted: light ? '#475569' : '#9fb2d4',
      track: light ? 'rgba(15,23,42,.08)' : 'rgba(255,255,255,.08)',
      goal: light ? '#1d4ed8' : '#60a5fa'
    };
  }

  function parseJSON(s, fb) { try { var v = JSON.parse(s); return Array.isArray(v) ? v : fb; } catch (e) { return fb; } }

  /* Prepara canvas com devicePixelRatio e retorna ctx + tamanho lógico */
  function setupCanvas(cv, cssH) {
    var w = cv.parentElement ? cv.parentElement.clientWidth : 320;
    if (w < 100) w = 320;
    var dpr = window.devicePixelRatio || 1;
    cv.width = Math.round(w * dpr);
    cv.height = Math.round(cssH * dpr);
    cv.style.width = w + 'px';
    cv.style.height = cssH + 'px';
    var ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, cssH);
    return { ctx: ctx, w: w, h: cssH };
  }

  function ensureLegend(cv) {
    var el = cv.nextElementSibling;
    if (!el || !el.classList.contains('chart-legend')) {
      el = document.createElement('div');
      el.className = 'chart-legend';
      cv.insertAdjacentElement('afterend', el);
    }
    return el;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]; }); }

  /* ---------- Donut ---------- */
  function drawDonut(cv) {
    var labels = parseJSON(cv.getAttribute('data-labels'), []);
    var values = parseJSON(cv.getAttribute('data-values'), []).map(Number);
    var center = cv.getAttribute('data-center') || '';
    var emptyMsg = cv.getAttribute('data-empty') || 'Sem dados';
    var T = themeColors();
    var H = 200;
    var c = setupCanvas(cv, H);
    var total = values.reduce(function (a, b) { return a + (b > 0 ? b : 0); }, 0);
    var cx = c.w / 2, cy = H / 2, R = Math.min(c.w, H) / 2 - 10, r = R * 0.62;

    var legend = ensureLegend(cv);

    if (total <= 0) {
      c.ctx.beginPath();
      c.ctx.arc(cx, cy, (R + r) / 2, 0, Math.PI * 2);
      c.ctx.lineWidth = R - r;
      c.ctx.strokeStyle = T.track;
      c.ctx.stroke();
      c.ctx.fillStyle = T.muted;
      c.ctx.font = '700 13px Hanken Grotesk, system-ui, sans-serif';
      c.ctx.textAlign = 'center';
      c.ctx.textBaseline = 'middle';
      c.ctx.fillText(emptyMsg, cx, cy);
      legend.innerHTML = '';
      return;
    }

    var start = -Math.PI / 2;
    values.forEach(function (v, i) {
      if (v <= 0) return;
      var ang = (v / total) * Math.PI * 2;
      c.ctx.beginPath();
      c.ctx.arc(cx, cy, (R + r) / 2, start, start + ang);
      c.ctx.lineWidth = R - r;
      c.ctx.strokeStyle = colorFor(labels[i], i);
      c.ctx.lineCap = 'butt';
      c.ctx.stroke();
      start += ang;
    });

    c.ctx.fillStyle = T.text;
    c.ctx.font = '900 22px Hanken Grotesk, system-ui, sans-serif';
    c.ctx.textAlign = 'center';
    c.ctx.textBaseline = 'middle';
    c.ctx.fillText(String(total), cx, cy - 8);
    c.ctx.fillStyle = T.muted;
    c.ctx.font = '800 11px Hanken Grotesk, system-ui, sans-serif';
    c.ctx.fillText(center, cx, cy + 13);

    legend.innerHTML = labels.map(function (lb, i) {
      return '<span><i style="background:' + colorFor(lb, i) + '"></i>' + esc(lb) + ' (' + (values[i] || 0) + ')</span>';
    }).join('');
  }

  /* ---------- Barras horizontais ---------- */
  function drawBars(cv) {
    var labels = parseJSON(cv.getAttribute('data-labels'), []);
    var values = parseJSON(cv.getAttribute('data-values'), []).map(Number);
    var goal = Number(cv.getAttribute('data-goal') || 0);
    var T = themeColors();
    var n = Math.max(labels.length, 1);
    var rowH = 34, padT = 6, padB = 18;
    var H = padT + n * rowH + padB;
    var c = setupCanvas(cv, H);

    var legend = ensureLegend(cv);
    legend.innerHTML = goal > 0 ? '<span><i style="background:transparent;border:2px dashed ' + T.goal + ';width:14px;height:0"></i>Meta: ' + goal + '</span>' : '';

    if (!labels.length) {
      c.ctx.fillStyle = T.muted;
      c.ctx.font = '700 13px Hanken Grotesk, system-ui, sans-serif';
      c.ctx.textAlign = 'center';
      c.ctx.fillText('Sem dados no mês', c.w / 2, H / 2);
      return;
    }

    var maxV = Math.max.apply(null, values.concat([goal, 1]));
    var labelW = Math.min(c.w * 0.34, 130);
    var barX = labelW + 8;
    var barW = c.w - barX - 34;

    labels.forEach(function (lb, i) {
      var y = padT + i * rowH;
      var v = values[i] || 0;
      var bw = Math.max((v / maxV) * barW, v > 0 ? 4 : 0);
      var color = goal > 0 ? (v >= goal ? '#22c55e' : '#3b82f6') : colorFor(lb, i);

      // nome
      c.ctx.fillStyle = T.muted;
      c.ctx.font = '800 11px Hanken Grotesk, system-ui, sans-serif';
      c.ctx.textAlign = 'right';
      c.ctx.textBaseline = 'middle';
      var name = String(lb);
      if (name.length > 16) name = name.slice(0, 15) + '…';
      c.ctx.fillText(name, labelW, y + rowH / 2);

      // trilha
      c.ctx.fillStyle = T.track;
      roundRect(c.ctx, barX, y + 8, barW, rowH - 16, 8);
      c.ctx.fill();

      // barra
      if (bw > 0) {
        c.ctx.fillStyle = color;
        roundRect(c.ctx, barX, y + 8, bw, rowH - 16, 8);
        c.ctx.fill();
      }

      // valor
      c.ctx.fillStyle = T.text;
      c.ctx.font = '900 12px Hanken Grotesk, system-ui, sans-serif';
      c.ctx.textAlign = 'left';
      c.ctx.fillText(String(v), barX + barW + 6, y + rowH / 2);
    });

    // linha da meta
    if (goal > 0 && goal <= maxV) {
      var gx = barX + (goal / maxV) * barW;
      c.ctx.save();
      c.ctx.strokeStyle = T.goal;
      c.ctx.setLineDash([5, 4]);
      c.ctx.lineWidth = 2;
      c.ctx.beginPath();
      c.ctx.moveTo(gx, padT);
      c.ctx.lineTo(gx, padT + n * rowH);
      c.ctx.stroke();
      c.ctx.restore();
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    if (w < 2 * r) r = w / 2;
    if (h < 2 * r) r = h / 2;
    if (r < 0) r = 0;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function drawAll() {
    document.querySelectorAll('canvas[data-chart="donut"]').forEach(drawDonut);
    document.querySelectorAll('canvas[data-chart="bars"]').forEach(drawBars);
  }

  /* ---------- Init ---------- */
  function init() {
    drawAll();
    window.addEventListener('vn:themechange', drawAll);
    var t;
    window.addEventListener('resize', function () {
      clearTimeout(t);
      t = setTimeout(drawAll, 150);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
