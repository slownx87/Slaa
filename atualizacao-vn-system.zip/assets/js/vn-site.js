/* =========================================================================
   VN System — vn-site.js · v1
   Site público: formulário de orçamento (abre o WhatsApp e registra o contato),
   máscara de telefone e botão "mostrar senha" do login.
   ========================================================================= */
(function () {
  'use strict';

  function maskPhone(el) {
    el.addEventListener('input', function () {
      var d = el.value.replace(/\D+/g, '').slice(0, 11);
      var out = d;
      if (d.length > 10) out = '(' + d.slice(0, 2) + ') ' + d.slice(2, 7) + '-' + d.slice(7);
      else if (d.length > 6) out = '(' + d.slice(0, 2) + ') ' + d.slice(2, 6) + '-' + d.slice(6);
      else if (d.length > 2) out = '(' + d.slice(0, 2) + ') ' + d.slice(2);
      else if (d.length > 0) out = '(' + d;
      el.value = out;
    });
  }

  function initQuoteForm(form) {
    var msg = form.querySelector('.s-form-msg');
    var say = function (text, kind) { if (msg) { msg.textContent = text; msg.className = 's-form-msg ' + (kind || ''); } };

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!form.checkValidity()) { form.reportValidity(); return; }
      var v = function (n) { var el = form.elements[n]; return el ? String(el.value || '').trim() : ''; };
      if (v('website') !== '') return; // campo-isca: robôs preenchem, pessoas não

      var texto = 'Olá! Gostaria de solicitar um orçamento:\n\n' +
        '*Nome:* ' + v('nome') + '\n' +
        '*Empresa/Condomínio:* ' + v('empresa') + '\n' +
        '*Telefone:* ' + v('telefone') + '\n' +
        '*E-mail:* ' + v('email') + '\n' +
        '*Serviço:* ' + v('servico') + '\n' +
        '*Mensagem:* ' + v('mensagem');
      var url = 'https://wa.me/' + String(form.getAttribute('data-wa') || '').replace(/\D+/g, '') + '?text=' + encodeURIComponent(texto);

      // Abre o WhatsApp primeiro (precisa ser dentro do clique, senão o navegador bloqueia).
      var w = window.open(url, '_blank', 'noopener');
      if (!w) { window.location.href = url; }

      // Registra o contato para a equipe acompanhar; falha aqui nunca atrapalha o envio.
      try {
        fetch(form.getAttribute('data-lead') || 'lead.php', { method: 'POST', body: new FormData(form), keepalive: true, credentials: 'same-origin' })
          .catch(function () {});
      } catch (err) {}

      say('Abrimos o WhatsApp com a sua mensagem. Se ele não abriu, toque em "Enviar" de novo.', 'ok');
    });
  }

  function initPassToggle(btn) {
    var input = document.getElementById(btn.getAttribute('data-toggle-pass'));
    if (!input) return;
    btn.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-pressed', show ? 'true' : 'false');
      btn.setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
      var ic = btn.querySelector('.material-symbols-outlined');
      if (ic) ic.textContent = show ? 'visibility_off' : 'visibility';
    });
  }

  function init() {
    document.querySelectorAll('input[name="telefone"]').forEach(maskPhone);
    document.querySelectorAll('[data-whatsapp-form]').forEach(initQuoteForm);
    document.querySelectorAll('[data-toggle-pass]').forEach(initPassToggle);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
