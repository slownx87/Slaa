/* =========================================================================
   VN System — Tela do pedido (pedido.php) · v1
   Abas (pedido/agenda/financeiro), menu "⋮", seções recolhíveis, janelas e foto ampliada.
   Os formulários são normais (POST); confirmações vêm do vn-ui.js ([data-confirm]).
   ========================================================================= */
(function () {
  'use strict';
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  /* ---- abas ---- */
  function aba(nome) {
    $$('[data-aba]').forEach(function (b) { b.setAttribute('aria-selected', b.getAttribute('data-aba') === nome ? 'true' : 'false'); });
    $$('[data-painel]').forEach(function (p) { p.hidden = p.getAttribute('data-painel') !== nome; });
    $$('[data-rodape]').forEach(function (p) { p.hidden = p.getAttribute('data-rodape') !== nome; });
    $$('.pv-status').forEach(function (f) { f.hidden = (f.getAttribute('data-quando') || '').split(' ').indexOf(nome) === -1; });
    $$('[data-aba-atual]').forEach(function (i) { i.value = nome; });
    try { var u = new URL(window.location.href); u.searchParams.set('aba', nome); window.history.replaceState(null, '', u.toString()); } catch (e) {}
  }
  $$('[data-aba]').forEach(function (b) { b.addEventListener('click', function () { aba(b.getAttribute('data-aba')); window.scrollTo(0, 0); }); });
  var ativa = $('[data-aba][aria-selected="true"]');
  aba(ativa ? ativa.getAttribute('data-aba') : 'pedido');

  /* ---- menu "⋮" ---- */
  var botaoMenu = $('[data-menu]'), menu = $('.pv-menu');
  function fechaMenu() { if (menu && !menu.hidden) { menu.hidden = true; botaoMenu.setAttribute('aria-expanded', 'false'); } }
  if (botaoMenu && menu) {
    botaoMenu.addEventListener('click', function (e) { e.stopPropagation(); menu.hidden = !menu.hidden; botaoMenu.setAttribute('aria-expanded', menu.hidden ? 'false' : 'true'); });
    document.addEventListener('click', function (e) { if (!e.target.closest('.pv-menu-wrap')) fechaMenu(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') fechaMenu(); });
  }

  /* ---- seções e janelas ---- */
  document.addEventListener('click', function (e) {
    var t = e.target;
    var sec = t.closest('[data-secao]');
    if (sec) { var s = sec.closest('.pv-sec'); s.classList.toggle('fechada'); sec.setAttribute('aria-expanded', s.classList.contains('fechada') ? 'false' : 'true'); return; }
    var f = t.closest('[data-fechar]'); if (f) { var d = f.closest('dialog'); if (d) d.close(); return; }
    var a = t.closest('[data-abrir]');
    if (a) { var m = document.getElementById(a.getAttribute('data-abrir')); if (m && m.showModal) { m.showModal(); var i = $('input:not([type=hidden]),select', m); if (i && !window.matchMedia('(max-width:900px)').matches) i.focus(); } return; }
    var foto = t.closest('[data-foto]');
    if (foto) { $('#pvFotoImg').src = foto.getAttribute('data-foto'); $('#pvFoto').showModal(); return; }
    if (t.matches && t.matches('dialog.pl-sheet')) t.close();   // clique no fundo
  });
})();
